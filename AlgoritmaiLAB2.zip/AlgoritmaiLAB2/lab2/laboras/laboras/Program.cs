﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboras
{
    class Program
    { 
        static long F1(int n)
        {
            if (n > 1) return ((F1(n - 1)) + 6 * (F1(n / 4)) + 7 * ((F1(n - 6)) * (F1(n - 6))) + (4 * (n * n * n) / 5));
            else if (n <= 1) return 4;
            else return 0;
        }
        static long F2(int n)
        {
            if (n > 1)
            {
                long[] f = new long [n+1];
                f[1] = 4;
                for (int i = 2; i <= n; i++)
                {
                    if ( i < 8) f[i]= f[i-1] + 6 * f[1] + 7 * ((long)Math.Pow((f[1]), 2)) + (4 * (i * i * i) / 5);
                    else f[i] = f[i - 1] + 6 * f[i / 4] + 7 * ((long)Math.Pow((f[i - 6]), 2)) + (4 * (i * i * i) / 5);
                }
                return f[n];
            }
            else if (n <= 1) return 4;
            else return 0;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Paprastu būdu:");
            Console.WriteLine("{0, -15}{1, -15:f5}", "Narys", "Atlikimo laikas");
            Console.WriteLine();
            int n = 15; int k = 10;
            variantasA(n, k);
            Console.WriteLine("Dinaminio programavimo būdu:");
            Console.WriteLine("{0, -15}{1, -15:f5}", "Narys", "Atlikimo laikas");
            Console.WriteLine();
            variantasB(n, k);
        }
    
        static void variantasA(int n, int k)
        {
            for (int i = 1; i < k; i++)
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                F1(n); 
                watch.Stop();
                double time = watch.Elapsed.TotalSeconds;
                Console.WriteLine("{0, -15}{1, -15:f5}", n, time);
                n = n + 5;
            }
        }
        static void variantasB(int n, int k)
        { 
            for (int i = 1; i < 25; i++)
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                F2(i);
                watch.Stop();
                double time = watch.Elapsed.TotalSeconds;
                Console.WriteLine("{0, -15}{1, -15:f5}", n, time);
                n = n * 2;
            }
        }
    }
}
