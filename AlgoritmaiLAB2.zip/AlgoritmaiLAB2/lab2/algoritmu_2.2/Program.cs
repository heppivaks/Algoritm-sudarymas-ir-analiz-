﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace algoritmu_2._2
{
    class Program
    {
        public static ulong opKiekis;
        Dictionary<double, double> memo = new Dictionary<double, double>();
        Dictionary<double, double> fib = new Dictionary<double, double>();
        public static int cost = 0;
        public static int kiekk = 0; //Kintamasis operacijos skaičiuoti 

        static void Main(string[] args)
        {
            Program op = new Program();
            Console.WriteLine("Iveskite kiek euru:");

            var K = new int[] { 10, 20, 50 };
            int m = K.Length; int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Ismoketi " + n + " euru yra budu: " + Variantu_kiekis(K, m, n));
            op.Skaiciavimai(); Console.ReadLine();

        }

        public void Skaiciavimai()
        {
            var K = new int[] { 10, 20, 50 }; 
            int m = K.Length; 
            opKiekis = 0;
            int n = 200; 
            Console.WriteLine("\n      N        Run Time       Operaciju kiekis\n");

            for (int i = 0; i < 9; i++)
            {

                Stopwatch myTimer = new Stopwatch();

                myTimer.Start(); Variantu_kiekis(K, m, n); 
                myTimer.Stop(); 
                Console.WriteLine(" {0,9:N0} {1} {2,15:N0} ", n, myTimer.Elapsed, opKiekis);
                n = n * 2; GC.Collect();
            }
        }

        //table[i] =  galimybiu skaicius gauti n suma

        static long Variantu_kiekis(int[] K, int m, int n)
        {
            opKiekis = opKiekis + 1;
            var table = new long[n + 1];   //galimybiu kiekis, sukuriama lentele su dydziu n+1 , 
                                            //saugo tasku skaiciu nuo 0 iki n, kiekviena galima reiksme prideda i lentele
            table[0] = 1;               //bazinis atvejis, kai reiksme= 0
            for (int i = 0; i < m; i++)
            {
                opKiekis = opKiekis + 1;
                for (int j = K[i]; j <= n; j++)
                {
                    opKiekis = opKiekis + 1;
                    table[j] += table[j - K[i]];  // iraso tarpines reiksmes, kad nereiktu is naujo skaiciuoti vel
                }
            }
            return table[n];
        }
    } 
}
//is eiles apsvarsto kiekviena is triju variantu, 
//atnaujina table reiksmes po to kai indeksas tampa didesnis arba lygus sutiktai reiksmei
