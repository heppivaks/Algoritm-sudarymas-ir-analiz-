﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Laboras_2
{
    class Program
    {

        static void Main(string[] args)
        {
            Program band = new Program();
            Console.WriteLine("Pasirinkite skaičių");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Atsakymas rekursijos: {0}", F1(n));
            Console.WriteLine("Atsakymas dinaminio programavimo: {0}", F2(n));
            int a = n;


            Console.WriteLine("\n Rekursija \n       N       Run Time    \n");
            for (int i = 0; i < 6; i++)
            {
                Stopwatch myTimer = new Stopwatch();
                myTimer.Start();
                F1(n);
                myTimer.Stop();
                Console.WriteLine("  {0,6:N0}   {1}  ", n, myTimer.Elapsed);
                n = n + 10;

            }

       
            Console.WriteLine("\n Dinaminis programavimas \n       N       Run Time    \n");
            for (int i = 0; i < 6; i++)
            {
                Stopwatch myTimer = new Stopwatch();
                myTimer.Start();
                F2(a);
                myTimer.Stop();
                Console.WriteLine("  {0,6:N0}   {1}  ", a, myTimer.Elapsed);
                a = a + 10;
            }

            
        }

        public static int F1(int n) {
            if (n > 1) return F1(n - 3) + 4 * F1(n / 6) + 9 * (F1(n / 7)) + n * n * n / 2;
            else return 1;
        }

        public static int F2(int n)
        {
            int f1;
            int f2;
            int f3;
            int[] final = new int[n+1];
            for (int i = 0; i <= n; i++) {
                if (i > 1){

                    f1 = Math.Max(i - 3, 0);
                    f2 = Math.Max(i / 6, 0);
                    f3 = Math.Max((i / 7), 0);
                   
                    final[i] = (final[f1] + (4 * final[f2]) + (9* final[f3])  + i * i * i / 2);

                }
                else {
                    final[i] = 1;
                }
            }
            return final[n];
        }

     
    }

}
