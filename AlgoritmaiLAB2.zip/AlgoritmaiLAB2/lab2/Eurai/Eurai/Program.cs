﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;


namespace Eurai
{
    class Program
    {
        public static ulong opMcout;
        Dictionary<double, double> memo = new Dictionary<double, double>();
        Dictionary<double, double> fib = new Dictionary<double, double>();
        public static int cost = 0;
        public static int kiekk = 0; //Kintamasis operacijos skaičiuoti

        static void Main(string[] args)
        {
            Program O = new Program();
            Console.WriteLine("Iveskite kiek euru:");

            var C = new int[] { 10, 20, 50 };
            int m = C.Length;
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Ismoketi " + n + " euru yra budu: "  + Count(C, m, n));
            O.Analysis();
            Console.ReadLine();

        }

        static long Count(int[] C, int m, int n)
        {
            opMcout = opMcout + 1;
            var table = new long[n + 1];
            table[0] = 1;
            for (int i = 0; i < m; i++)
            {
                opMcout = opMcout + 1;
                for (int j = C[i]; j <= n; j++)
                {
                    opMcout = opMcout + 1;
                    table[j] += table[j - C[i]];
                }
            }
            return table[n];
        }

        public void Analysis()
        {
            var C = new int[] { 10, 20, 50 };
            int m = C.Length;
            opMcout = 0;
            int n = 100;
            Console.WriteLine("\n F1 \n      N        Run Time       Op M Count\n");

            for (int i = 0; i < 7; i++)
            {

                Stopwatch myTimer = new Stopwatch();

                myTimer.Start();
                Count(C, m, n);
                myTimer.Stop();
                Console.WriteLine(" {0,6:N0} {1} {2,15:N0} ", n,
                myTimer.Elapsed, opMcout);
                n = n * 2;
                GC.Collect();
            }
        }
        public static void random(int n, int[,] table)
        {

            Random rand = new Random(); // reikalingas random skaičių generavimui
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    table[i, j] = rand.Next(1, 10);
                }
            }
        }
        public static void Random_Rekursiniui(int n, int m, int[,] table, int[,] Next)
        {
            int right = 1; kiekk++;
            int down = 2; kiekk++;
            Random rand = new Random(); // reikalingas random skaičių generavimui
            for (int i = 0; i < n; i++)
            {
                kiekk++;
                for (int j = 0; j < m; j++)
                {
                    kiekk++;
                    table[i, j] = rand.Next(1, 10);
                }
            }

            for (int i = 0; i < n; i++)
            {
                // Console.WriteLine();
                for (int j = 0; j < m; j++)
                {
                    kiekk++;
                    // Console.Write("{0,4}", table[i, j]);
                }
            }

            //Console.WriteLine();
            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {
                    if (table[i, j + 1] <= table[i + 1, j] && table[i, j + 1] == 0)
                    {
                        kiekk++;
                        Next[i, j] = down;
                    }

                    else if (table[i, j + 1] <= table[i + 1, j])
                    {
                        kiekk++;
                        Next[i, j] = down;
                    }

                    else if (table[i, j + 1] >= table[i + 1, j] && table[i + 1, j] == 0)
                    {
                        kiekk++;
                        Next[i, j] = right;
                    }

                    else if (table[i, j + 1] >= table[i + 1, j])
                    {
                        kiekk++;
                        Next[i, j] = right;
                    }
                }
            }
        }





    }
}
