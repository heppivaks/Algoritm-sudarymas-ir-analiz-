﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Laboras_2
{
    class Program
    {
        public static ulong opKiekis;
        static void Main(string[] args)
        {
            Program band = new Program();
            Console.WriteLine("Pasirinkite bet kokį skaičių, su kuriuo skaičiuotų atsakymus: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Atsakymas skaičiuojant rekursijos:metodu  {0}", F1(n));
            Console.WriteLine("Atsakymas skaičiuojant dinaminiu programavimu: {0}", F2(n));
            int a = n;

            opKiekis = 0;
            Console.WriteLine("\n Rekursija \n N       Run Time    Operacijų kiekis\n");
            for (int i = 1; i <15; i++)
            {
                Stopwatch myWatch = new Stopwatch();
                myWatch.Start();
                F1(n);
                myWatch.Stop();
                double time = myWatch.Elapsed.TotalSeconds;
                Console.WriteLine("{0, -15}{1, -15:f5}{2, -15}", n, time, opKiekis);
                n = n + 300;
            }

            opKiekis = 0;
            Console.WriteLine("\n Dinaminis programavimas \n N       Run Time    Operacijų kiekis\n");
            for (int i = 1; i < 15; i++)
            {
                Stopwatch myTimer = new Stopwatch();
                myTimer.Start();
                F2(a);
                myTimer.Stop();
                double time = myTimer.Elapsed.TotalSeconds;
                Console.WriteLine("{0, -15}{1, -15:f5}{2, -15}", a, time, opKiekis);
                a = a + 300 ;
            }


        }

        public static int F1(int n)
        {
            opKiekis = opKiekis + 1;
            if (n > 1)
            {
                return F1(n - 3) + 4 * F1(n / 6) + 9 * (F1(n / 7)) + n * n * n / 2;
                opKiekis = opKiekis + 1;
            }
            else return 1;
        }

        public static int F2(int n)
        {
            opKiekis = opKiekis + 1;
            int f1;
            int f2;
            int f3;

            int[] final = new int[n + 1];
            for (int i = 0; i <= n; i++)
            {
                opKiekis = opKiekis + 1;
                if (i > 1)
                {

                    f1 = Math.Max(i - 3, 0);  // tikrina ar i-3 daugiau uz 0, jei daugiau ima i-3, 
                    f2 = Math.Max((i / 6), 0);
                    f3 = Math.Max((i / 7), 0);

                    final[i] = (final[f1] + (4 * final[f2]) + (9 * final[f3]) + i * i * i / 2);
                    opKiekis = opKiekis + 1;

                }
                else
                {
                    final[i] = 1;
                    opKiekis = opKiekis + 1;
                }
            }
            opKiekis = opKiekis + 1;
            return final[n];
        }


    }

}
