﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmaiLAB2
{
    class Program
    {
        private class Data
        {
            public int TNum;
            public int TResult;
        }
        static void Main(string[] args)
        {
            string[] count = File.ReadAllLines(@"data.csv");
            string[] countcol = count[1].Split(',');
            int n = countcol.Length - 1;
            int A = count.Length - 1;
            Console.WriteLine(V(3, 7));
        }

        static int VL(int n, int A, int start, int countCPU)
        {
            if(A == 0)
            {
                return 0;
            }
            List<int> ListV = new List<int>();
            for (int i = start; i < A; i += countCPU)
            {
                if (n >= 0)
                {
                    int temp = R(n, a) + V(n - 1, A - a);
                    ListV.Add(temp);
                }
            }
            if (ListV.Count > 0)
            {
                return ListV.Max();
            }
            else return 0;
        }

        static int VLygiagreturs(int n, int A)
        {
            int result = 0;
            if (A != 0)
            {
                int countCPU = 4;
                Task[] tasks = new Task[countCPU];
                for (int j = 0; j < countCPU; j++)
                {
                    tasks[j] = Task.Factory.StartNew(
                        (object p))
                }
            }
        }

        static int V(int n, int A)
        {
            if (A == 0)
            {
                return 0;
            }
            List<int> ListV = new List<int>();
            for (int a = 0; a <= A; a++)
            {
                if (n >= 0)
                {
                    int temp = R(n, a) + V(n - 1, A - a);
                    ListV.Add(temp);
                }
                    
                                
            }
            if (ListV.Count > 0)
            {
                return ListV.Max();
            }
            else return 0;
        }

        static int R(int n, int a)
        {
            string[] text = File.ReadAllLines(@"data.csv");
            string[] values = text[a].Split(',');
            return int.Parse(values[n]);

        }
    }
}
