﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Algoritmu_L1
{
    class HeapOP
    {
        //static void Main(string[] args)
        //{
        //    int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
        //    Test_Array_List(seed);
        //}

        //----------------------------------------------------------RIKIAVIMAI-------------------------------------------------//
        public static void HeapSort(DataArray items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapify(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0, items[i], items[0]);

                heapSize--;
                MaxHeapify(items, heapSize, 0);
            }
        }

        private static void MaxHeapify(DataArray items, int heapSize, int index)
        {
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items[left] > items[index])
                largest = left;
            else
                largest = index;

            if (right < heapSize && items[right] > items[largest])
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest, items[index], items[largest]);

                MaxHeapify(items, heapSize, largest);
            }
        }

        public static void HeapSort(DataList items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapify1(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0);

                heapSize--;
                MaxHeapify1(items, heapSize, 0);
            }
        }

        private static void MaxHeapify1(DataList items, int heapSize, int index)
        {
            double currentdata = items.Head();
            double prevdata = items.Next();
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items.Get(left) > items.Get(index))
                largest = left;
            else
                largest = index;

            if (right < heapSize && items.Get(right) > items.Get(largest))
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapify1(items, heapSize, largest);
            }
        }
        public static void Test_Array_List(int seed)
        {
            int n = 0;
            MyDataArray myarray = new MyDataArray(n, seed);
            Stopwatch laikas = new Stopwatch();

            MyDataList mylist = new MyDataList(n, seed);
            Stopwatch laikas2 = new Stopwatch();

            Console.WriteLine("\n                   Heap Sort  OP |ARRAY|LIST \n");

            for (int i = 0; i < 7; i++)
            {
                n += 1000;
                myarray = new MyDataArray(n, seed);
                laikas.Start();
                HeapSort(myarray);
                laikas.Stop();
                mylist = new MyDataList(n, seed);
                //mylist.Print(n);
                laikas2.Start();
                HeapSort(mylist);
                laikas2.Stop();
                //mylist.Print(n);
                Console.WriteLine("Algoritmo laikas milisekundėmis: | {0}   | {1}  \nGeneruojant {2} duomenų", laikas.Elapsed, laikas2.Elapsed, n);
                Console.WriteLine();
            }
        }
        //----------------------------------------------------------------------KLASES--------------------------------------------------------------//
        public abstract class DataList
        {

            protected int length;
            public int Length { get { return length; } }
            public abstract int Head();
            public abstract int Next();
            public abstract int Previous();
            public abstract void Append(int item, int index);
            public abstract int Get(int index);
            public abstract void Swap(int a, int b);
            public void Print(int n)
            {
                Console.Write(" {0} ", Head());
                for (int i = 1; i < n; i++)
                    Console.Write(" {0} ", Next());
                Console.WriteLine();
            }

        }

        public class MyDataList : DataList
        {
            class Node
            {
                public Node Next { get; set; }
                public Node Previous { get; set; }
                public int Data { get; set; }
                public Node(int data, Node previous, Node next)
                {
                    this.Data = data;
                    this.Previous = previous;
                    this.Next = next;
                }
                public Node(int data)
                {
                    this.Data = data;
                }
            }
            Node first;
            Node prev;
            Node last;
            Node current;

            public MyDataList()
            {
                first = null;
                current = null;
                last = null;
                length = 0;
            }
            public MyDataList(int n, int seed)
            {
                length = n;
                Random rand = new Random(seed);
                first = new Node(rand.Next(1, 1000));
                current = first;
                for (int i = 1; i < length; i++)
                {
                    prev = current;
                    current.Next = new Node(rand.Next(1, 1000));
                    current = current.Next;
                }
                current.Next = null;
                last = current;
            }

            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }

            public override int Head()
            {
                current = first;
                return current.Data;
            }

            public override int Next()
            {
                current = current.Next;
                return current.Data;
            }

            public override int Previous()
            {
                current = current.Previous;
                return current.Data;
            }

            public override void Swap(int a, int b)
            {
                if (a == b)
                    return;

                Node n1 = first;
                Node n2 = null;
                if (a > b)
                {
                    int i = 0;
                    while (i < b)
                    {
                        n1 = n1.Next;
                        i++;
                    }
                    n2 = n1;
                    while (i < a)
                    {
                        n2 = n2.Next;
                        i++;
                    }
                }
                else
                {
                    int i = 0;
                    while (i < a)
                    {
                        n1 = n1.Next;
                        i++;
                    }
                    n2 = n1;
                    while (i < b)
                    {
                        n2 = n2.Next;
                        i++;
                    }
                }
                int temp = n1.Data;
                n1.Data = n2.Data;
                n2.Data = temp;
            }

            public override string ToString()
            {
                return base.ToString();
            }

            public override int Get(int index)
            {
                int i = 0;
                Node node = first;
                while (i != index)
                {
                    i++;

                    node = node.Next;
                }
                return node.Data;
            }
            public override void Append(int newItem, int index)
            {
                Node newNode = new Node(newItem);
                if (length == 0)
                {
                    first = newNode;
                    last = first;
                }
                else
                {
                    last.Next = newNode;
                    last = last.Next;
                }
                length++;
            }
        }

        public abstract class DataArray
        {
            protected int length;
            public int Length { get { return length; } }
            public abstract int this[int index] { get; }
            public abstract void Swap(int i, int j, int a, int b);
            public void Print(int n)
            {
                for (int i = 0; i < n; i++)
                    Console.Write(" {0} ", this[i]);
                Console.WriteLine();
            }
        }

        class MyDataArray : DataArray
        {
            int[] data;
            public MyDataArray(int n, int seed)
            {
                data = new int[n];
                length = n;
                Random rand = new Random(seed);
                for (int i = 0; i < length; i++)
                {
                    data[i] = rand.Next(1, 1000);
                }
            }
            public override int this[int index]
            {
                get { return data[index]; }
            }
            public override void Swap(int i, int j, int a, int b)
            {
                data[j] = a;
                data[i] = b;
            }
        }
    }     
}
