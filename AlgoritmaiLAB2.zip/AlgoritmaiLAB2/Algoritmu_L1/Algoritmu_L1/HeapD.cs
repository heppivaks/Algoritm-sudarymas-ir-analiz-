﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace Algoritmu_L1
{
    class HeapD
    {
        //static void Main(string[] args)
        //{
        //    int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
        //    Test_File_Array_List(seed);
        //}
        //--------------------------------------------------RIKIAVIMAI---------------------------------------------------//

        public static void HeapSort(DataArray items)
        {
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapifyA(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                items.Swap(i, 0);

                heapSize--;
                MaxHeapifyA(items, heapSize, 0);
            }
        }

        private static void MaxHeapifyA(DataArray items, int heapSize, int index)
        {
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items[left] > items[index])
                largest = left;
            else
                largest = index;

            if (right < heapSize && items[right] > items[largest])
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapifyA(items, heapSize, largest);
            }
        }

        public static void HeapSort(DataList items)
        {
            int heapSize = items.Length;
            for (int i = (heapSize - 1) / 2; i >= 0; i--)
            {
                MaxHeapifyL(items, heapSize, i);
            }
            for (int i = items.Length - 1; i > 0; i--)
            {
                items.Swap(i, 0);

                heapSize--;
                MaxHeapifyL(items, heapSize, 0);
            }
        }

        private static void MaxHeapifyL(DataList items, int heapSize, int index)
        {
            double currentData = items.Head();
            double prevData = items.Next();
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items.Get(left) > items.Get(index))
                largest = left;
            else
                largest = index;

            if (right < heapSize && items.Get(right) > items.Get(largest))
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapifyL(items, heapSize, largest);
            }
        }

        //--------------------------------------------------------RIKIAVIMO PABAIGA------------------------------------------------//

        public static void Test_File_Array_List(int seed)
        {
            int n = 0;
            string filename, filename1;

            filename = @"mydataarray.dat";
            filename1 = @"mydatalist.dat";
            MyFileArray myfilearray = new MyFileArray(filename, n, seed);
            MyFileList myfilelist = new MyFileList(filename1, n, seed);
            Stopwatch stopwatch1 = new Stopwatch();
            Stopwatch stopwatch2 = new Stopwatch();

            Console.WriteLine("\n Heap Sort D \n");

            for (int i = 0; i < 7; i++)
            {
                n += 1000;
                myfilearray = new MyFileArray(filename, n, seed);
                myfilelist = new MyFileList(filename1, n, seed);
                using (myfilearray.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
                {
                   //  myfilearray.Print(n);
                    stopwatch1.Start();
                    HeapSort(myfilearray);
                    stopwatch1.Stop();
                  //    myfilearray.Print(n);
                    Console.WriteLine("Generuojant {0} duomenų \nAlgoritmo laikas milisekundėmis: ARRAY {1} ", n, stopwatch1.Elapsed);
                }

                using (myfilelist.fs = new FileStream(filename1, FileMode.Open, FileAccess.ReadWrite))
                {
                    //  myfilelist.Print(n);
                    stopwatch2.Start();
                    HeapSort(myfilelist);
                    stopwatch2.Stop();
                  //   myfilelist.Print(n);
                    Console.WriteLine("                                 LIST {0}", stopwatch2.Elapsed);
                }

                Console.WriteLine();
            }

            //using (myfilelist.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
            //{
            //    Console.WriteLine("\n Heap Sort FILE LIST \n");
            //    //  myfilelist.Print(n);
            //    stopwatch2.Start();
            //    HeapSortL(myfilelist);
            //    stopwatch2.Stop();
            //    // myfilelist.Print(n);
            //    Console.WriteLine("Algoritmo laikas milisekundėmis: {0} \nGeneruojant {1} duomenų", stopwatch2.ElapsedMilliseconds, n);
            //}
        }

        //--------------------------------------------------------KLASĖS-----------------------------------------------------------//

        public abstract class DataArray
        {
            protected int length;
            public int Length { get { return length; } }
            public abstract int this[int index] { get; }
            public abstract void Swap(int i, int j);
            public void Print(int n)
            {
                for (int i = 0; i < n; i++)
                    Console.Write(" " + this[i]);
                Console.WriteLine();
            }
        }

        public class MyFileArray : DataArray
        {
            public MyFileArray(string fileName, int n, int seed)
            {
                int[] data = new int[n];
                length = n;
                Random rand = new Random(seed);
                for (int i = 0; i < length; i++)
                {
                    data[i] = rand.Next(1, 1000);
                }
                if (File.Exists(fileName)) File.Delete(fileName);
                try
                {
                    using(BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                    {
                        for (int j = 0; j < length; j++)
                            writer.Write(data[j]);
                    }
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            public FileStream fs { get; set; }

            public override int this[int index]
            {
                get
                {
                    Byte[] data = new Byte[4];
                    fs.Seek(4 * index, SeekOrigin.Begin);
                    fs.Read(data, 0, 4);
                    int result = BitConverter.ToInt32(data, 0);
                    return result;
                }
            }

            public override void Swap(int i, int j)
            {
                Byte[] data1 = new Byte[4];
                Byte[] data2 = new Byte[4];
                fs.Seek(4 * i, SeekOrigin.Begin);
                fs.Read(data1, 0, 4);
                fs.Seek(4 * j, SeekOrigin.Begin);
                fs.Read(data2, 0, 4);
                fs.Seek(4 * i, SeekOrigin.Begin);
                fs.Write(data2, 0, 4);
                fs.Seek(4 * j, SeekOrigin.Begin);
                fs.Write(data1, 0, 4);
            }
        }

        public abstract class DataList
        {
            protected int length;
            public int Length { get { return length; } }
            public abstract int Head();
            public abstract int Next();
            public abstract int Get(int index);
            public abstract void Swap(int i, int j);
            public void Print(int n)
            {
                Console.Write(" {0} ", Head());
                for (int i = 1; i < n; i++)
                    Console.Write(" {0} ", Next());
                Console.WriteLine();
            }
        }

        class MyFileList : DataList
        {
            int prevNode;
            int currentNode;
            int nextNode;

            public MyFileList(string fileName, int n, int seed)
            {
                length = n;
                Random rand = new Random(seed);
                if (File.Exists(fileName)) File.Delete(fileName);
                try
                {
                    using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.Create)))
                    {
                        writer.Write(4);
                        prevNode = 0;
                        for (int i = 0; i < length; i++)
                        {
                            int ran = rand.Next(1, 1000);
                            writer.Write(ran);

                            if (i > 0)
                                writer.Write((i - 1) * 12 + 4);
                            else writer.Write(0);
                            writer.Write((i + 1) * 12 + 4);
                        }
                    }
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            public FileStream fs { get; set; }

            public override int Head()
            {
                Byte[] data = new Byte[12];
                fs.Seek(0, SeekOrigin.Begin);
                fs.Read(data, 0, 4);
                currentNode = BitConverter.ToInt32(data, 0);
                prevNode = -1;
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Read(data, 0, 12);
                int result = BitConverter.ToInt32(data, 0);
                nextNode = BitConverter.ToInt32(data, 8);
                return result;
            }

            public override int Next()
            {
                Byte[] data = new Byte[12];
                fs.Seek(nextNode, SeekOrigin.Begin);
                fs.Read(data, 0, 12);
                prevNode = currentNode;
                currentNode = nextNode;
                int result = BitConverter.ToInt32(data, 0);
                nextNode = BitConverter.ToInt32(data, 8);
                return result;
            }

            public override void Swap(int a, int b)
            {
                Byte[] data1 = new Byte[4];
                Byte[] data2 = new Byte[4];
                Head();
                for (int i = 0; i < a; i++)
                    Next();
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Read(data1, 0, 4);
                Head();
                for (int i = 0; i < b; i++)
                    Next();
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Read(data2, 0, 4);
                Head();
                for (int i = 0; i < a; i++)
                    Next();
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Write(data2, 0, 4);
                Head();
                for (int i = 0; i < b; i++)
                    Next();
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Write(data1, 0, 4);
            }

            public override int Get(int index)
            {
                Byte[] data = new Byte[12];
                fs.Seek(index * 12, SeekOrigin.Begin);
                fs.Read(data, 0, 12);
                int result = BitConverter.ToInt32(data, 4);
                return result;
            }
        }
    }
}
