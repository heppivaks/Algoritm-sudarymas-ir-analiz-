﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace Algoritmu_L1
{
    class SelectionD
    {
        static void Main(string[] args)
        {
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            Test_File_Array_List(seed);
        }

        //------------------------------------------RIKIAVIMAI----------------------------//
        public static void SelectionSortA(DataArray items)
        {
            int min;
            for (int i = 0; i < items.Length; i++)
            {
                min = i;
                for (int j = i+1; j < items.Length; j++)
                {
                    if (items[j] < items[min])
                    {
                        min = j;
                    }
                }
                if (min != i)
                {
                    for (int j = min; j > i; j--)
                    {
                        items.Swap(j, items[j], items[j - 1]);
                    }
                }
            }
        }

        public static void SelectionSortL(DataList items)
        {
            double max = 0;
            double prevdata, currentdata;
            for (int i = items.Length - 1; i >= 0 ; i--)
            {
                currentdata = items.Head();
                max = currentdata;
                for (int j = 0; j < i; j++)
                {
                    currentdata = items.Next();
                    if (currentdata > max)
                    {
                        max = currentdata;
                    }
                }
                currentdata = items.Head();
                for (int m = 0; m <= i -1 ; m++)
                {
                    prevdata = currentdata;
                    currentdata = items.Next();
                    if (prevdata == max)
                    {
                        items.Swap(currentdata, prevdata);
                        currentdata = prevdata;
                    }
                }
                max = 0;
            }
        }

        //---------------------------------------------------------PABAIGA--------------------------------//
        public static void Test_File_Array_List(int seed)
        {
            int n = 0;
            string filename, filename1;

            filename = @"mydataarray.dat";
            MyFileArray myfilearray = new MyFileArray(filename, n, seed);
            Stopwatch laikas = new Stopwatch();
            filename1 = @"mydatalist.dat";
            MyFileList myfilelist = new MyFileList(filename, n, seed);
            Stopwatch laikas2 = new Stopwatch();

            Console.WriteLine("\n Selection Sort D \n");

            for (int i = 0; i < 10; i++)
            {
                n += 10;
                myfilearray = new MyFileArray(filename, n, seed);
                myfilelist = new MyFileList(filename1, n, seed);
                using (myfilearray.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
                {
                   // myfilearray.Print(n);
                    laikas.Start();
                    SelectionSortA(myfilearray);
                    laikas.Stop();
                    Console.WriteLine("Generuojant {0} duomenų \nAlgoritmo laikas milisekundėmis: ARRAY {1} ", n, laikas.Elapsed);
                    // myfilearray.Print(n);
                }
                using (myfilelist.fs = new FileStream(filename1, FileMode.Open, FileAccess.ReadWrite))
                {
                    laikas2.Start();
                    SelectionSortL(myfilelist);
                    laikas2.Stop();
                    Console.WriteLine("                                 LIST {0}", laikas2.Elapsed);
                }
                Console.WriteLine();
            }

            //using (myfilelist.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
            //{
            ////    Console.WriteLine("\n FILE LIST \n");
            ////   // myfilelist.Print(n);
            ////    laikas2.Start();
            ////    SelectionSortL(myfilelist);
            ////    laikas2.Stop();
            ////    Console.WriteLine("Algoritmo laikas milisekundėmis: {0} \nGeneruojant {1} duomenų", laikas2.ElapsedMilliseconds, n);
            ////  //  myfilelist.Print(n);
            //}
        }
        //---------------------------------------------------------KLASES---------------------------------//

        public abstract class DataArray
        {
            protected int length;

            public int Length { get { return length; } }
            public abstract double this[int index] { get; }
            public abstract void Swap(int j, double a, double b);
            public void Print(int n)
            {
                for (int i = 0; i < n; i++)
                    Console.Write(" {0} ", this[i]);
                Console.WriteLine();
            }
        }

        public abstract class DataList
        {
            protected int length;
            public int Length { get { return length; } }
            public abstract double Head();
            public abstract double Next();
            public abstract void Swap(double a, double b);
            public void Print(int n)
            {
                Console.Write(" {0} ", Head());
                for (int i = 1; i < n; i++)
                    Console.Write(" {0} ", Next());
                Console.WriteLine();
            }
        }

        class MyFileArray : DataArray
        {
            public MyFileArray(string filename, int n, int seed)
            {
                double[] data = new double[n];
                length = n;
                Random rand = new Random(seed);
                for (int i = 0; i < length; i++)
                {
                    data[i] = rand.NextDouble();
                }
                if (File.Exists(filename)) File.Delete(filename);
                try
                {
                    using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Create)))
                    {
                        for (int j = 0; j < length; j++)
                            writer.Write(data[j]);
                    }
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }

            public FileStream fs { get; set; }

            public override double this[int index]
            {
                get
                {
                    Byte[] data = new Byte[8];
                    fs.Seek(8 * index, SeekOrigin.Begin);
                    fs.Read(data, 0, 8);
                    double result = BitConverter.ToDouble(data, 0);
                    return result;
                }
            }

             public override void Swap(int j, double a, double b)
            {
                Byte[] data = new Byte[16];
                BitConverter.GetBytes(a).CopyTo(data, 0);
                BitConverter.GetBytes(b).CopyTo(data, 8);
                fs.Seek(8 * (j - 1), SeekOrigin.Begin);
                fs.Write(data, 0, 16);
            }
        }

        class MyFileList : DataList
        {
            int prevNode;
            int currentNode;
            int nextNode;

            public MyFileList(string filename, int n, int seed)
            {
                length = n;
                Random rand = new Random(seed);
                if (File.Exists(filename)) File.Delete(filename);
                try
                {
                    using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Create)))
                    {
                        writer.Write(4);
                        for (int j = 0; j < length; j++)
                        {
                            writer.Write(rand.NextDouble());
                            writer.Write((j + 1) * 12 + 4);
                        }
                    }
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            public FileStream fs { get; set; }
            public override double Head()
            {
                Byte[] data = new Byte[12];
                fs.Seek(0, SeekOrigin.Begin);
                fs.Read(data, 0, 4);
                currentNode = BitConverter.ToInt32(data, 0);
                prevNode = -1;
                fs.Seek(currentNode, SeekOrigin.Begin);
                fs.Read(data, 0, 12);
                double result = BitConverter.ToDouble(data, 0);
                nextNode = BitConverter.ToInt32(data, 8);
                return result;
            }
            public override double Next()
            {
                Byte[] data = new Byte[12];
                fs.Seek(nextNode, SeekOrigin.Begin);
                fs.Read(data, 0, 12);
                prevNode = currentNode;
                currentNode = nextNode;
                double result = BitConverter.ToDouble(data, 0);
                nextNode = BitConverter.ToInt32(data, 8);
                return result;
            }
            public override void Swap(double a, double b)
            {
                Byte[] data;
                fs.Seek(prevNode, SeekOrigin.Begin);
                data = BitConverter.GetBytes(a);
                fs.Write(data, 0, 8);
                fs.Seek(currentNode, SeekOrigin.Begin);
                data = BitConverter.GetBytes(b);
                fs.Write(data, 0, 8);
            }
        }
    }
}
