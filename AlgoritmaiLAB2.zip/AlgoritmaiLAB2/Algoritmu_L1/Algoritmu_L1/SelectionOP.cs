﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Algoritmu_L1
{
    class SelectionOP
    {
        //static void Main(string[] args)
        //{
        //    int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
        //    Test_Array_List(seed);
        //}

        //------------------------------------RIKIAVIMAI---------------------------------------------
        public static void SelectionSortA(DataArray items)
        {
            int min;
            for (int i = 0; i < items.Length; i++)
            {
                min = i;
                for (int j = i + 1; j < items.Length; j++)
                {
                    if (items[j] < items[min])
                    {
                        min = j;
                    }
                }
                if (min != i)
                {
                    for (int j = min; j > i; j--)
                    {
                        items.Swap(j, items[j], items[j - 1]);
                    }
                }
            }
        }

        public static void SelectionSortL(DataList items)
        {
            int max = 0;
            int prevdata, currentdata;
            for (int i = items.Length - 1; i >= 0; i--)
            {
                currentdata = items.Head();
                max = currentdata;
                for (int j = 0; j < i; j++)
                {
                    currentdata = items.Next();
                    if (currentdata > max)
                    {
                        max = currentdata;
                    }

                }
                currentdata = items.Head();
                for (int m = 0; m <= i - 1; m++)
                {
                    prevdata = currentdata;
                    currentdata = items.Next();
                    if (prevdata == max)
                    {
                        items.Swap(currentdata, prevdata);
                        currentdata = prevdata;
                    }

                }
                max = 0;
            }

        }
        //-----------------------------------------------------------Rikiavimu pabaiga------------------------------------------------------------------------------



        public static void Test_Array_List(int seed)
        {
            int n = 5;
            MyDataArray myarray1 = new MyDataArray(n, seed);
            Stopwatch myTimer = new Stopwatch();
            Stopwatch myTimer3 = new Stopwatch();

            MyDataList mylist1 = new MyDataList(n, seed);
            Console.WriteLine("\n               Selection Sort OP |ARRAY| LIST \n");
                myarray1 = new MyDataArray(n, seed);
                mylist1 = new MyDataList(n, seed);
                 myarray1.Print(n);
                myTimer.Start();
                SelectionSortA(myarray1);
                myTimer.Stop();
             //   myTimer3.Start();
             //   SelectionSortL(mylist1);
             //   myTimer3.Stop();
                Console.WriteLine("Algoritmo laikas milisekundėmis: | {0}   | {1} \nGeneruojant {2} duomenų", myTimer.ElapsedMilliseconds, myTimer3.ElapsedMilliseconds, n);
                myarray1.Print(n);
           
          //  Console.WriteLine("\n LIST Selection \n");
          ////  mylist1.Print(n);
          
          //  Console.WriteLine("Algoritmo laikas milisekundėmis: {0} \nGeneruojant {1} duomenų", myTimer.ElapsedMilliseconds, n);
           // mylist1.Print(n);
        }



        //------------------------------------------Klasės-----------------------------------------------------
        public abstract class DataArray
        {
            protected int length;

            public int Length { get { return length; } }
            public abstract int this[int index] { get; }
            //public abstract int Length { get; } 
            public abstract void Swap(int j, int a, int b);
            public void Print(int n)
            {
                for (int i = 0; i < n; i++)
                    Console.Write(" {0} ", this[i]);
                Console.WriteLine();
            }
        }

        class MyDataArray : DataArray
        {

            int[] data;
            public MyDataArray(int n, int seed)
            {
                data = new int[n];
                length = n;
                Random rand = new Random();
                for (int i = 0; i < length; i++)
                {
                    data[i] = rand.Next(1, 5000);
                }
            }
            public override int this[int index]
            {
                get { return data[index]; }

            }
            public override void Swap(int j, int a, int b)
            {
                data[j - 1] = a;
                data[j] = b;
            }
        }




        public abstract class DataList
        {
            protected int length;
            public int Length { get { return length; } }
            public abstract int Head();
            public abstract int Next();
            public abstract void Swap(int a, int b);
            public abstract bool Exists();
            public abstract int getData();
            public abstract void ChangeNode(int count, int data);
            public void Print(int n)
            {
                Console.Write(" {0} ", Head());
                for (int i = 1; i < n; i++)
                    Console.Write(" {0} ", Next());
                Console.WriteLine();
            }
        }

        class MyDataList : DataList
        {
            class MyLinkedListNode
            {
                public MyLinkedListNode nextNode { get; set; }
                public int data { get; set; }
                public MyLinkedListNode(int data)
                {
                    this.data = data;
                }
            }
            MyLinkedListNode headNode;
            MyLinkedListNode prevNode;
            MyLinkedListNode currentNode;
            public MyDataList(int n, int seed)
            {
                length = n;
                Random rand = new Random();
                headNode = new MyLinkedListNode(rand.Next(1, 5000));
                currentNode = headNode;
                for (int i = 1; i < length; i++)
                {
                    prevNode = currentNode;
                    currentNode.nextNode = new MyLinkedListNode(rand.Next(1, 5000));
                    currentNode = currentNode.nextNode;
                }
                currentNode.nextNode = null;
            }
            public override int Head()
            {
                currentNode = headNode;
                prevNode = null;
                return currentNode.data;
            }
            public override int Next()
            {
                prevNode = currentNode;
                currentNode = currentNode.nextNode;
                return currentNode.data;
            }
            public override void Swap(int a, int b)
            {
                prevNode.data = a;
                currentNode.data = b;
            }
            public override bool Exists()
            {
                return currentNode.nextNode != null;
            }
            public override int getData()
            {
                return currentNode.data;
            }
            public override void ChangeNode(int count, int data)
            {
                if (count <= length)
                {
                    MyLinkedListNode ToChange = headNode;
                    for (int i = 0; i < count; i++)
                    {
                        ToChange = ToChange.nextNode;
                    }
                    ToChange.data = data;
                }
            }
        }
    }
}




