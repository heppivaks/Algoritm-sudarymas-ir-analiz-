﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace HeapSort_D
{
    class Program
    {
        static void Main(string[] args)
        {
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            Test_File_Array_List(seed);
        }
        public static void Test_File_Array_List(int seed)
        {
            int n = 2000;
            string filename;

            filename = @"mydataarray.dat";
            Stopwatch stopwatch1 = new Stopwatch();
            MyFileArray myfilearray = new MyFileArray(filename, n, seed);
            using (myfilearray.fs = new FileStream(filename, FileMode.Open,
            FileAccess.ReadWrite))
            {
                Console.WriteLine("\n Heap Sort FILE ARRAY \n");
                //myfilearray.Print(n);
                stopwatch1.Start();
                HeapSort(myfilearray);
                stopwatch1.Stop();
                //myfilearray.Print(n);
                Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch1.ElapsedMilliseconds, n);
            }

            filename = @"mydatalist.dat";
            Stopwatch stopwatch2 = new Stopwatch();
            MyFileList myfilelist = new MyFileList(filename, n, seed);
            using (myfilelist.fs = new FileStream(filename, FileMode.Open,
            FileAccess.ReadWrite))
            {
                Console.WriteLine("\n Heap Sort FILE LIST \n");
                //myfilelist.Print(n);
                stopwatch2.Start();
                HeapSort(myfilelist);
                stopwatch2.Stop();
                //myfilelist.Print(n);
                Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch2.ElapsedMilliseconds, n);
            }
        }

        public static void HeapSort(DataArray items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapify(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0);

                heapSize--;
                MaxHeapify(items, heapSize, 0);
            }
        }

        private static void MaxHeapify(DataArray items, int heapSize, int index)
        {
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items[left] > items[index])
                largest = left;
            else
                largest = index;

            if (right < heapSize && items[right] > items[largest])
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapify(items, heapSize, largest);
            }
        }

        public static void HeapSort(DataList items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
            {
                MaxHeapify1(items, heapSize, p);
            }

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0);

                heapSize--;
                MaxHeapify1(items, heapSize, 0);
            }
        }

        private static void MaxHeapify1(DataList items, int heapSize, int index)
        {
            double currentdata = items.Head();
            double prevdata = items.Next();
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items.Get(left) > items.Get(index))
                largest = left;
            else
                largest = index;

            if (right < heapSize && items.Get(right) > items.Get(largest))
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapify1(items, heapSize, largest);
            }
        }
    }
}
