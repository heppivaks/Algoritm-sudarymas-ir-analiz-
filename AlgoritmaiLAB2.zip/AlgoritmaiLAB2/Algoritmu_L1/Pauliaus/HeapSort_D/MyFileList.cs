﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HeapSort_D
{
    abstract class DataList
    {
        protected int length;
        public int Length { get { return length; } }
        public abstract int Head();
        public abstract int Next();
        public abstract int Get(int index);
        public abstract void Swap(int i, int j);
        public void Print(int n)
        {
            Console.Write(" {0} ", Head());
            for (int i = 1; i < n; i++)
                Console.Write(" {0} ", Next());
            Console.WriteLine();
        }
    }

    class MyFileList : DataList
    {
        int prevNode;
        int currentNode;
        int nextNode;
        public MyFileList(string filename, int n, int seed)
        {
            length = n;
            Random rand = new Random(seed);
            if (File.Exists(filename)) File.Delete(filename);
            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Create)))
                {
                    writer.Write(4);
                    prevNode = 0;
                    for (int i = 0; i < length; i++)
                    {
                        int ran = rand.Next(1, 1000);
                        writer.Write(ran);

                        if (i > 0)
                            writer.Write((i - 1) * 12 + 4);
                        else writer.Write(0);
                        writer.Write((i + 1) * 12 + 4);
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public FileStream fs { get; set; }

        public override int Head()
        {
            Byte[] data = new Byte[12];
            fs.Seek(0, SeekOrigin.Begin);
            fs.Read(data, 0, 4);
            currentNode = BitConverter.ToInt32(data, 0);
            prevNode = -1;
            fs.Seek(currentNode, SeekOrigin.Begin);
            fs.Read(data, 0, 12);
            int result = BitConverter.ToInt32(data, 0);
            nextNode = BitConverter.ToInt32(data, 8);
            return result;
        }

        public override int Next()
        {
            Byte[] data = new Byte[12];
            fs.Seek(nextNode, SeekOrigin.Begin);
            fs.Read(data, 0, 12);
            prevNode = currentNode;
            currentNode = nextNode;
            int result = BitConverter.ToInt32(data, 0);
            nextNode = BitConverter.ToInt32(data, 8);
            return result;
        }

        public override void Swap(int a, int b)
        {
            Byte[] data1 = new Byte[4];
            Byte[] data2 = new Byte[4];
            Head();
            for (int i = 0; i < a; i++)
                Next();
            fs.Seek(currentNode, SeekOrigin.Begin);
            fs.Read(data1, 0, 4);
            Head();
            for (int i = 0; i < b; i++)
                Next();
            fs.Seek(currentNode, SeekOrigin.Begin);
            fs.Read(data2, 0, 4);
            Head();
            for (int i = 0; i < a; i++)
                Next();
            fs.Seek(currentNode, SeekOrigin.Begin);
            fs.Write(data2, 0, 4);
            Head();
            for (int i = 0; i < b; i++)
                Next();
            fs.Seek(currentNode, SeekOrigin.Begin);
            fs.Write(data1, 0, 4);
        }

        public override int Get(int index)
        {
            Byte[] data = new Byte[12];
            fs.Seek(index * 12, SeekOrigin.Begin);
            fs.Read(data, 0, 12);
            int result = BitConverter.ToInt32(data, 4);
            return result;
        }
    }
}
