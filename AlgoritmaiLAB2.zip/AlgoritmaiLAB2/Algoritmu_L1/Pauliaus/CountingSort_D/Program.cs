﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace CountingSort_D
{
    class Program
    {
        static void Main(string[] args)
        {
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            Test_File_Array_List(seed);
        }
        public static void Test_File_Array_List(int seed)
        {
            int n = 32000;
            string filename;

            filename = @"mydataarray.dat";

            Stopwatch stopwatch1 = new Stopwatch();
            FileArray myfilearray = new FileArray(filename, n, seed);
            using (myfilearray.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
            {
                Console.WriteLine("\n Counting Sort FILE ARRAY \n");
                //myfilearray.Print(n);
                stopwatch1.Start();
                CountingSort(myfilearray);
                stopwatch1.Stop();
                //myfilearray.Print(n);
                Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch1.ElapsedMilliseconds, n);
            }

            filename = @"mydatalist.dat";

            Stopwatch stopwatch2 = new Stopwatch();
            FileList myfilelist = new FileList(filename, n, seed);
            using (myfilelist.fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
            {
                Console.WriteLine("\n Counting Sort FILE LIST \n");
                //myfilelist.Print(n);
                stopwatch2.Start();
                CountingList(myfilelist);
                stopwatch2.Stop();
                //myfilelist.Print(n);
                Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch2.ElapsedMilliseconds, n);
            }
        }

        public static void CountingSort(FileArray Array)
        {
            int[] sortedArray = new int[Array.Length];

            // find smallest and largest value
            int minVal = Array[0];
            int maxVal = Array[0];
            sortedArray[0] = Array[0];
            for (int i = 1; i < Array.Length; i++)
            {
                sortedArray[i] = Array[i];
                if (Array[i] < minVal) minVal = Array[i];
                else if (Array[i] > maxVal) maxVal = Array[i];
            }

            // init array of frequencies
            int[] counts = new int[maxVal - minVal + 1];

            // init the frequencies
            for (int i = 0; i < Array.Length; i++)
            {
                counts[Array[i] - minVal]++;
            }

            // recalculate
            counts[0]--;
            for (int i = 1; i < counts.Length; i++)
            {
                counts[i] = counts[i] + counts[i - 1];
            }

            // Sort the array
            for (int i = Array.Length - 1; i >= 0; i--)
            {
                Array.Set(counts[sortedArray[i] - minVal]--, sortedArray[i]);
            }
        }

        public static void CountingList(FileList Array)
        {
            int[] sortedArray = new int[Array.Length];

            // find smallest and largest value
            int minVal = Array.Head();
            int maxVal = minVal;
            sortedArray[0] = minVal;
            for (int i = 1; i < Array.Length; i++)
            {
                int currentNumber = Array.Next();
                sortedArray[i] = currentNumber;
                if (currentNumber < minVal) minVal = currentNumber;
                else if (currentNumber > maxVal) maxVal = currentNumber;
            }

            // init array of frequencies
            int[] counts = new int[maxVal - minVal + 1];

            // init the frequencies
            for (int i = 0; i < Array.Length; i++)
            {
                counts[Array.GetNode(i) - minVal]++;
            }

            // recalculate
            counts[0]--;
            for (int i = 1; i < counts.Length; i++)
            {
                counts[i] = counts[i] + counts[i - 1];
            }

            // Sort the array
            for (int i = Array.Length - 1; i >= 0; i--)
            {
                Array.GetNode(counts[sortedArray[i] - minVal]--);
                Array.Set(sortedArray[i]);
            }
        }
    }
}
