﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapSort_OP
{
    abstract class DataArray
    {
        protected int length;
        public int Length { get { return length; } }
        public abstract int this[int index] { get; }
        public abstract void Swap(int i, int j, int a, int b);
        public void Print(int n)
        {
            for (int i = 0; i < n; i++)
                Console.Write(" {0} ", this[i]);
            Console.WriteLine();
        }
    }

    class MyDataArray : DataArray
    {
        int[] data;
        public MyDataArray(int n, int seed)
        {
            data = new int[n];
            length = n;
            Random rand = new Random(seed);
            for (int i = 0; i < length; i++)
            {
                data[i] = rand.Next(1, 1000);
            }
        }
        public override int this[int index]
        {
            get { return data[index]; }
        }
        public override void Swap(int i, int j, int a, int b)
        {
            data[j] = a;
            data[i] = b;
        }
    }
}
