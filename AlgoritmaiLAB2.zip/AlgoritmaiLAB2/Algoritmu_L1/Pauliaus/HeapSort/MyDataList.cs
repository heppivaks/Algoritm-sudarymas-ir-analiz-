﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeapSort_OP
{
    abstract class DataList
    {
        protected int length;
        public int Length { get { return length; } }
        public abstract int Head();
        public abstract int Next();
        public abstract int Previous();
        public abstract void Append(int item, int index);
        public abstract int Get(int index);
        public abstract void Swap(int a, int b);
        public void Print(int n)
        {
            Console.Write(" {0} ", Head());
            for (int i = 1; i < n; i++)
                Console.Write(" {0} ", Next());
            Console.WriteLine();
        }
    }

    class MyDataList : DataList
    {
        class Node
        {
            public Node Next { get; set; }
            public Node Previous { get; set; }
            public int Data { get; set; }
            public Node(int data, Node previous, Node next)
            {
                this.Data = data;
                this.Previous = previous;
                this.Next = next;
            }
            public Node(int data)
            {
                this.Data = data;
            }
        }
        Node first;
        Node prev;
        Node last;
        Node current;

        public MyDataList()
        {
            first = null;
            current = null;
            last = null;
            length = 0;
        }
        public MyDataList(int n, int seed)
        {
            length = n;
            Random rand = new Random(seed);
            first = new Node(rand.Next(1, 1000));
            current = first;
            for (int i = 1; i < length; i++)
            {
                prev = current;
                current.Next = new Node(rand.Next(1, 1000));
                current = current.Next;
            }
            current.Next = null;
            last = current;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override int Head()
        {
            current = first;
            return current.Data;
        }

        public override int Next()
        {
            current = current.Next;
            return current.Data;
        }

        public override int Previous()
        {
            current = current.Previous;
            return current.Data;
        }

        public override void Swap(int a, int b)
        {
            if (a == b)
                return;

            Node n1 = first;
            Node n2 = null;
            if (a > b)
            {
                int i = 0;
                while (i < b)
                {
                    n1 = n1.Next;
                    i++;
                }
                n2 = n1;
                while (i < a)
                {
                    n2 = n2.Next;
                    i++;
                }
            }
            else
            {
                int i = 0;
                while (i < a)
                {
                    n1 = n1.Next;
                    i++;
                }
                n2 = n1;
                while (i < b)
                {
                    n2 = n2.Next;
                    i++;
                }
            }
            int temp = n1.Data;
            n1.Data = n2.Data;
            n2.Data = temp;
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public override int Get(int index)
        {
            int i = 0;
            Node node = first;
            while (i != index)
            {
                i++;

                node = node.Next;
            }
            return node.Data;
        }
        public override void Append(int newItem, int index)
        {
            Node newNode = new Node(newItem);
            if (length == 0)
            {
                first = newNode;
                last = first;
            }
            else
            {
                last.Next = newNode;
                last = last.Next;
            }
            length++;
        }
    }
}
