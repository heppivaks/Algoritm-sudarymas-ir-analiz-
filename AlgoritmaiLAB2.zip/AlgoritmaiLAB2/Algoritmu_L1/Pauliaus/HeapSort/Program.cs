﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace HeapSort_OP
{
    class Program
    {
        static void Main(string[] args)
        {
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            Test_Array_List(seed);
        }

        public static void Test_Array_List(int seed)
        {
            int n = 32000;

            Stopwatch stopwatch1 = new Stopwatch();
            MyDataArray myarray = new MyDataArray(n, seed);
            Console.WriteLine("\n Heap Sort ARRAY \n");
            //myarray.Print(n);
            stopwatch1.Start();
            HeapSort(myarray);
            stopwatch1.Stop();
            //myarray.Print(n);
            Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch1.ElapsedMilliseconds, n);

            Stopwatch stopwatch2 = new Stopwatch();
            MyDataList mylist = new MyDataList(n, seed);
            Console.WriteLine("\n Heap Sort LIST \n");
            //mylist.Print(n);
            stopwatch2.Start();
            HeapSort(mylist);
            stopwatch2.Stop();
            //mylist.Print(n);
            Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch2.ElapsedMilliseconds, n);
        }

        public static void HeapSort(DataArray items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapify(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0, items[i], items[0]);

                heapSize--;
                MaxHeapify(items, heapSize, 0);
            }
        }

        private static void MaxHeapify(DataArray items, int heapSize, int index)
        {
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items[left] > items[index])
                largest = left;
            else
                largest = index;

            if (right < heapSize && items[right] > items[largest])
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest, items[index], items[largest]);

                MaxHeapify(items, heapSize, largest);
            }
        }

        public static void HeapSort(DataList items)
        {
            //Build-Max-Heap
            int heapSize = items.Length;
            for (int p = (heapSize - 1) / 2; p >= 0; p--)
                MaxHeapify1(items, heapSize, p);

            for (int i = items.Length - 1; i > 0; i--)
            {
                //Swap
                items.Swap(i, 0);

                heapSize--;
                MaxHeapify1(items, heapSize, 0);
            }
        }

        private static void MaxHeapify1(DataList items, int heapSize, int index)
        {
            double currentdata = items.Head();
            double prevdata = items.Next();
            int left = (index + 1) * 2 - 1;
            int right = (index + 1) * 2;
            int largest = 0;

            if (left < heapSize && items.Get(left) > items.Get(index))
                largest = left;
            else
                largest = index;

            if (right < heapSize && items.Get(right) > items.Get(largest))
                largest = right;

            if (largest != index)
            {
                items.Swap(index, largest);

                MaxHeapify1(items, heapSize, largest);
            }
        }
    }
}
