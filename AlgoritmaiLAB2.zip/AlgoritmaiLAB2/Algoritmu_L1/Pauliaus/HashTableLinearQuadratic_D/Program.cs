﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace HashTableLinearQuadratic_D
{
    class Program
    {
        static Random random;

        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            Dictionary<string, string> nameList = new Dictionary<string, string>();
            HashTableLinearQuadratic strTree = new HashTableLinearQuadratic();
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            random = new Random(seed);
            int n = 32000;
            for (int i = 0; i < n; i++)
            {
                string name = RandomName(10);
                string lastName = RandomName(10);
                nameList.Add(lastName, name);
                strTree.Put(lastName, name);
            }
            nameList.Add(RandomName(10), RandomName(10));

            Console.WriteLine(" Hash Table Linear Quadratic hashing FILE \n");
            //strTree.Print();
            //Console.WriteLine("\n Search Test FILE \n");

            string filename = @"mydatatree.dat";
            strTree.WriteToFile(filename, n);

            stopwatch.Start();
            using (FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
            {
                foreach (var s in nameList)
                {
                    bool contains = strTree.FileContains(fs, s.Key, s.Value, n, 10);
                    //Console.WriteLine(contains + " -> Searched Key - [" + s.Key + "] / Searched Value - [" + s.Value + "]");
                }
            }
            stopwatch.Stop();
            //Console.WriteLine();
            Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu \n", stopwatch.ElapsedMilliseconds, n);
        }

        static string RandomName(int size)
        {
            StringBuilder builder = new StringBuilder();
            char ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
            builder.Append(ch);
            for (int i = 1; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 97)));
                builder.Append(ch);
            }
            return builder.ToString();
        }
    }
}
