﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HashTableLinearQuadratic_D
{
    public class HashTableLinearQuadratic
    {
        int _usedSpace;
        int _basicSize;
        public Entry[] _entries;

        public HashTableLinearQuadratic()
            : this(16)
        {
        }

        public HashTableLinearQuadratic(int basicSize)
        {
            _basicSize = basicSize;
            _entries = new Entry[_basicSize];
            _usedSpace = 0;
        }

        public void Put(string key, string value)
        {
            if (_usedSpace >= _basicSize)
                Resize();

            int index = FindIndex(key);
            if (index == -1)
            {
                Resize();
                Put(key, value);
                return;
            }

            Entry currentEntry = _entries[index];
            if (currentEntry != null)
            {
                currentEntry._value = value;
                return;
            }
            _entries[index] = new Entry(key, value);

            _usedSpace++;
        }

        public string Get(string key)
        {
            int index = FindIndex(key);
            if (index == -1)
                return null;
            if (_entries[index] == null)
                return null;
            return _entries[index]._value;
        }

        public bool ContainsKey(string key)
        {
            int index = FindIndex(key);
            if (index == -1)
                return false;
            return _entries[index] != null;
        }

        public int Size()
        {
            return _usedSpace;
        }

        public void Clear()
        {
            for (int i = 0; i < _entries.Length; i++)
                _entries[i] = null;
            _usedSpace = 0;
        }

        public bool IsEmpty()
        {
            return _usedSpace == 0;
        }

        private void Resize()
        {
            _basicSize *= 2;
            Entry[] oldEntries = _entries;
            _entries = new Entry[_basicSize];

            int index;
            for (int i = 0; i < oldEntries.Length; i++)
            {
                Entry entry = oldEntries[i];
                if (entry == null)
                    continue;
                index = FindIndex(entry.GetKey());
                _entries[index] = new Entry(entry.GetKey(), entry.GetValue());
            }
        }

        private int FindIndex(string key)
        {
            int originalHash = key.GetHashCode() < 0 ? key.GetHashCode() * -1 : key.GetHashCode();
            int hash;
            for (int j = 0; j < _basicSize; j++)
            {
                hash = (originalHash + j * j) % _basicSize;
                if (_entries[hash] == null || _entries[hash] != null && _entries[hash]._key == key)
                    return hash;
            }
            return -1;
        }

        public void Print()
        {
            foreach (Entry entry in _entries)
            {
                if (entry == null)
                    continue;
                Console.WriteLine(entry.GetKey() + " -> " + entry.GetValue());
            }
        }

        public void WriteToFile(string filename, int n)
        {
            if (File.Exists(filename)) File.Delete(filename);
            try
            {
                using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Create)))
                {
                    foreach (Entry entry in _entries)
                    {
                        if (entry == null)
                            continue;
                        writer.Write(entry._key + entry._value);
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public bool FileContains(FileStream fs, string key, string value, int t, int k)
        {
            byte[] data = new byte[k * 2 + 1];
            for (int i = 0; i < t; i++)
            {
                fs.Seek(i * (k * 2 + 1), SeekOrigin.Begin);
                fs.Read(data, 0, k * 2 + 1);
                string readKey = Encoding.ASCII.GetString(data, 1, k);
                string readValue = Encoding.ASCII.GetString(data, k + 1, k);
                if (readKey.Equals(key) && readValue.Equals(value))
                    return true;
            }
            return false;
        }

        public class Entry
        {
            internal string _key { get; set; }
            internal string _value { get; set; }

            public Entry(string key, string value)
            {
                _key = key;
                _value = value;
            }

            public string GetKey()
            {
                return _key;
            }

            public string GetValue()
            {
                return _value;
            }
        }
    }
}
