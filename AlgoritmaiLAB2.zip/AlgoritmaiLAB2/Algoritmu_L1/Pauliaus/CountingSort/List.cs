﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountingSort_OP
{
    public class Node
    {
        public int NodeContent;
        public Node Next;
        public Node Prev;
    }
    public class List
    {
        private int size;
        public int Count
        {
            get
            {
                return size;
            }
        }

        public Node head;
        private Node current;

        public List()
        {
            size = 0;
            head = null;
        }

        public void Add(int content)
        {
            size++;

            Node node = new Node
            {
                NodeContent = content
            };

            if (head == null)
                head = node;
            else
            {
                current.Next = node;
                node.Prev = current;
            }

            current = node;
        }

        public void ListNodes()
        {
            Node tempNode = head;

            while (tempNode != null)
            {
                Console.WriteLine(tempNode.NodeContent);
                tempNode = tempNode.Next;
            }
        }

        public Node Get(int Position)
        {
            Node tempNode = head;
            Node retNode = null;
            int count = 0;

            while (tempNode != null)
            {
                if (count == Position - 1)
                {
                    retNode = tempNode;
                    break;
                }
                count++;
                tempNode = tempNode.Next;
            }

            return retNode;
        }

        public void printAllNodes()
        {
            Node current = head;
            Console.Write(" ");
            while (current != null)
            {
                Console.Write("{0} ", current.NodeContent);
                current = current.Next;
            }
            Console.WriteLine();
        }

        public void SelectionSort()
        {
            int temp;
            for (Node node = head; node.Next != null; node = node.Next)
            {
                Node min = node;
                for (Node node1 = node.Next; node1 != null; node1 = node1.Next)
                {
                    if (node1.NodeContent < min.NodeContent)
                        min = node1;
                }

                temp = min.NodeContent;
                min.NodeContent = node.NodeContent;
                node.NodeContent = temp;
            }
        }
    }
}
