﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace CountingSort_OP
{
    class Program
    {
        static void Main(string[] args)
        {
            int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
            Test_Array_List(seed);
        }

        public static void Test_Array_List(int seed)
        {

            Random rnd = new Random(seed);
            int n = 32000;

            Stopwatch stopwatch1 = new Stopwatch();
            rnd = new Random(seed);
            int[] array = new int[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = rnd.Next(1, 1000);
            }
            Console.WriteLine("\n Counting Sort ARRAY \n");
            //Console.Write(" ");
            //for (int i = 0; i < n; i++)
            //{
            //    Console.Write(array[i] + " ");
            //}
            //Console.WriteLine();
            stopwatch1.Start();
            int[] sortedArray = CountingSort(array);
            stopwatch1.Stop();
            //Console.Write(" ");
            //for (int i = 0; i < n; i++)
            //{
            //    Console.Write(sortedArray[i] + " ");
            //}
            //Console.WriteLine();
            Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch1.ElapsedMilliseconds, n);

            Stopwatch stopwatch2 = new Stopwatch();
            rnd = new Random(seed);
            List myList = new List();
            for (int i = 0; i < n; i++)
            {
                myList.Add(rnd.Next(1, 1000));
            }
            Console.WriteLine("\n Counting Sort LIST \n");
            //myList.printAllNodes();
            stopwatch2.Start();
            CountingList(myList);
            stopwatch2.Stop();
            //myList.printAllNodes();
            Console.WriteLine(" Algoritmo laikas milisekundėmis {0} su {1} duomenu", stopwatch2.ElapsedMilliseconds, n);
        }

        public static int[] CountingSort(int[] Array)
        {
            int[] sortedArray = new int[Array.Length];

            // find smallest and largest value
            int minVal = Array[0];
            int maxVal = Array[0];
            for (int i = 1; i < Array.Length; i++)
            {
                if (Array[i] < minVal) minVal = Array[i];
                else if (Array[i] > maxVal) maxVal = Array[i];
            }

            // init array of frequencies
            int[] counts = new int[maxVal - minVal + 1];

            // init the frequencies
            for (int i = 0; i < Array.Length; i++)
            {
                counts[Array[i] - minVal]++;
            }

            // recalculate
            counts[0]--;
            for (int i = 1; i < counts.Length; i++)
            {
                counts[i] = counts[i] + counts[i - 1];
            }

            // Sort the array
            for (int i = Array.Length - 1; i >= 0; i--)
            {
                sortedArray[counts[Array[i] - minVal]--] = Array[i];
            }

            return sortedArray;
        }

        public static void CountingList(List list)
        {
            int[] sortedArray = new int[list.Count];

            // find smallest and largest value
            int minVal = list.head.NodeContent;
            int maxVal = list.head.NodeContent;
            for (Node current = list.head.Next; current != null; current = current.Next)
            {
                if (current.NodeContent < minVal) minVal = current.NodeContent;
                else if (current.NodeContent > maxVal) maxVal = current.NodeContent;
            }

            // init array of frequencies
            int[] counts = new int[maxVal - minVal + 1];

            // init the frequencies
            for (Node current = list.head; current != null; current = current.Next)
            {
                counts[current.NodeContent - minVal]++;
            }

            // recalculate
            counts[0]--;
            for (int i = 1; i < counts.Length; i++)
            {
                counts[i] = counts[i] + counts[i - 1];
            }

            // Sort the array
            for (Node current = list.head; current != null; current = current.Next)
            {
                sortedArray[counts[current.NodeContent - minVal]--] = current.NodeContent;
            }
            int c = 0;
            for (Node current = list.head; current != null; current = current.Next)
            {
                current.NodeContent = sortedArray[c++];
            }
        }
    }
}
