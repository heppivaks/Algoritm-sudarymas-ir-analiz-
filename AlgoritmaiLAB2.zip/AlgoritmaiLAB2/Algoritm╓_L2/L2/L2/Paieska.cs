﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace L2
{
    class Paieska
    {
        private const int DuomenuKiekis = 1000;
        private const int DuomenuIlgis = 25;
        
        public void NuosekliPaieska()
        {
            LinearHashTable<int, string> hashTable = new LinearHashTable<int, string>();
            for (int i = 0; i < DuomenuKiekis; i++)
            {
                string randomString = Guid.NewGuid().ToString("n").Substring(0, DuomenuIlgis);
                hashTable.Add(i, randomString);
            }
            int count = 0;
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            for (int i = 0; i < DuomenuIlgis; i++)
            {
                string value = string.Empty;
                if (hashTable[i] != null)
                {
                    count++;
                }
            }
            stopWatch.Stop();
            Console.WriteLine("Paieška nenaudojant lygiagretinimo. Elementu sk: {0} Laikas: {1}\n", DuomenuKiekis, stopWatch.ElapsedMilliseconds);
        }

        public void Lygiagretus()
        {
            LinearHashTable<int, string> maišosLentelė = new LinearHashTable<int, string>();
            for (int i = 0; i < DuomenuKiekis; i++)
            {
                string atsitiktiniaiDuomenis = Guid.NewGuid().ToString("n").Substring(0, DuomenuIlgis);
                maišosLentelė.Add(i, atsitiktiniaiDuomenis);
            }
            int cpuSkaičius = 8;
            Task<int>[] uzduotys = new Task<int>[cpuSkaičius];
            Stopwatch laikas = new Stopwatch();
            laikas.Start();
            for (int j = 0; j < cpuSkaičius; j++)
            {
                uzduotys[j] = Task<int>.Factory.StartNew(
                    (object p) =>
                    {
                        int kiekis = 0;
                        for (int i = (int)p; i < DuomenuKiekis; i += cpuSkaičius)
                        {
                            string val = string.Empty;
                            if (maišosLentelė[i] != null)
                            {
                                kiekis++;
                            }
                        }
                        return kiekis;
                    }, j);
            }
            int bendras = 0;
            for (int i = 0; i < cpuSkaičius; i++)
            {
                bendras += uzduotys[i].Result;
            }
            laikas.Stop();
            Console.WriteLine("Paieška naudojant lygiagretinimą. Elementu sk: {0} Laikas: {1}\n", DuomenuKiekis, laikas.ElapsedMilliseconds);
            
        }
    }
}
