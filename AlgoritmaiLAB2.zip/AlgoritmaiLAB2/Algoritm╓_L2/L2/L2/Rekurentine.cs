﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2
{
    class Rekurentine
    {
        static void Main(string[] args)
        {
            int n = 5;
            int A = 20;

            int[,] Data = GenerateData(n, A);
            RecursionSolver RS = new RecursionSolver(Data);
            DPSolver DPS = new DPSolver(Data);
            Paieska paiesk = new Paieska();
            Lygiagretus lyg = new Lygiagretus(Data);

            paiesk.NuosekliPaieska();
            paiesk.Lygiagretus();

            Stopwatch laikasRek = new Stopwatch();
            laikasRek.Start();
            int recursionSolution = RS.V(n, A);
            laikasRek.Stop();

            Stopwatch laikasDin = new Stopwatch();
            laikasDin.Start();
            int dynamicSolution = DPS.V(n, A);
            laikasDin.Stop();

            Stopwatch laikasLyg = new Stopwatch();
            laikasLyg.Start();
            int lygiagretusRezultatas = lyg.LygiagretusV(n, A);
            laikasLyg.Stop();

            Console.WriteLine("Atsakymas, kai sprendžiama rekursiškai: {0}.\n Užtruko: {1} ms \n", recursionSolution, laikasRek.ElapsedMilliseconds);

            Console.WriteLine("Atsakymas, kai sprendžiama dinamiškai {0}. \n Užtruko: {1} ms \n", dynamicSolution, laikasDin.ElapsedMilliseconds);

            Console.WriteLine("Kai sprendžiama naudojant lygiagretinimą užtruko: {0} ms \n", laikasLyg.ElapsedMilliseconds);
        }
        static int[,] GenerateData(int n, int A)
        {
            Random rand = new Random();
            int[,] Data = new int[n, A + 1];
            for (int i = 0; i < n; i++)
                for (int j = 1; j <= A; j++)
                    Data[i, j] = rand.Next(1, 10);

            return Data;
        }
    }

    class Lygiagretus
    {
        private int[,] R;
        public Lygiagretus(int[,] R) { this.R = R; }

        private class Duomenys
        {
            public int TNum;
            public int TRezultatas;
        }

        public int V(int n, int A, int start, int countCPU)
        {
            if(A == 0 || n == 0)
            {
                return 0;
            }
            int didziausias = int.MinValue;
            for (int i = start; i < A; i+=countCPU)
            {
                int tarpinis = R[n - 1, i] + V(n - 1, A - i, start, countCPU);
                didziausias = tarpinis > didziausias ? tarpinis : didziausias;
            }
            return didziausias;
        }
        public int LygiagretusV(int n, int A)
        {
            int rezultatas = 0;
            if(A > 0 && n > 0)
            {
                int CPUskaicius = 4;
                Task[] uzduotys = new Task[CPUskaicius];
                for (int i = 0; i < CPUskaicius; i++)
                {
                    uzduotys[i] = Task.Factory.StartNew(
                        (Object p) =>
                        {
                            var data = p as Duomenys;
                            if(data == null)
                            {
                                return;
                            }
                        data.TRezultatas = V(n, A, data.TNum, CPUskaicius);
                        }, new Duomenys() { TNum = i });
                }
                Task.WaitAll(uzduotys);
                for (int i = 0; i < CPUskaicius; i++)
                {
                    if ((uzduotys[i].AsyncState as Duomenys).TRezultatas > rezultatas)
                    {
                        rezultatas = (uzduotys[i].AsyncState as Duomenys).TRezultatas;
                    }
                }
                return rezultatas;
            } else
            {
                return 0;
            }
        }
    }
    class RecursionSolver
    {
        private int[,] R;
        int rekursijosKvietimai = 0;
        public RecursionSolver(int[,] R) { this.R = R; }

        public int V(int n, int A)
        {
            rekursijosKvietimai++;
            if (A == 0 || n == 0)
                return 0;

            int highestSubProblem = int.MinValue;
            for (int a = 0; a <= A; a++)
            {
                int currentSubproblem = R[n - 1, a] + V(n - 1, A - a);
                highestSubProblem = currentSubproblem > highestSubProblem ? currentSubproblem : highestSubProblem;
            }
            return highestSubProblem;
        }
    }

    class DPSolver
    {
        private int[,] R;
        public DPSolver(int[,] R) { this.R = R; }

        public int V(int n, int A)
        { 
            int[,,] Rn = new int[n, A + 1, 2];

            for (int i = 0; i < n; i++)
            {
                for (int a = 0; a <= A; a++)
                {
                    if (i == 0)
                        Rn[i, a, 0] = R[i, a];
                    else
                    {
                        int highest = int.MinValue;

                        for (int k = 0; k <= a; k++)
                        {
                            int current = R[i, k] + Rn[i - 1, a - k, 0];
                            if (current > highest)
                            {
                                Rn[i, a, 0] = current;
                                Rn[i, a, 1] = a - k;
                                highest = current;
                            }
                        }
                    }
               //     Console.WriteLine("i = {0}     a = {1}     Rn(i, a, 0) = {2}        Rn(i, a, 1) = {3}        R(i, a) = {4}\n", i, a, Rn[i, a, 0], Rn[i, a, 1], R[i, a]);
                }
            }
            int highestSubProblem = int.MinValue;
            for (int i = 0; i <= A; i++)
                highestSubProblem = Rn[n - 1, i, 0] > highestSubProblem ? Rn[n - 1, i, 0] : highestSubProblem;
            return highestSubProblem;
        }
    }
}
