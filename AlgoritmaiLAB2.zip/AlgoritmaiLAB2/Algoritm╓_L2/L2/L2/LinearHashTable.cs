﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2
{
    public class LinearHashTable<Tkey, Tvalue> : IDictionary<Tkey, Tvalue>, IEnumerable
    {
        private List<KeyValuePair<Tkey, Tvalue>[]> keyValue;

        private int p;                      
        private int elementsOfArrayUsed;
        private int loadToMaintain;         
        private int maxP;                  
        private int capacity;
        private int originalMaxP;

        private List<KeyValuePair<Tkey, Tvalue>> newItems;
        private List<KeyValuePair<Tkey, Tvalue>> delItems;
        
        public LinearHashTable(int capacity, int loadToMaintain)
        {
            if (loadToMaintain < 1)
                throw new Exception("Load to maintain must be greater than or equal to 1");

            if (!IsPowerOfTwo((ulong)capacity))
                throw new Exception("Capacity must be a power of 2");

            this.loadToMaintain = loadToMaintain;
            this.capacity = capacity;

            newItems = new List<KeyValuePair<Tkey, Tvalue>>(loadToMaintain);
            delItems = new List<KeyValuePair<Tkey, Tvalue>>(loadToMaintain);

            keyValue = new List<KeyValuePair<Tkey, Tvalue>[]>(capacity);

            p = 0;
            elementsOfArrayUsed = 0;

            for (int i = 0; i < capacity; i++)
            {
                keyValue.Add(new KeyValuePair<Tkey, Tvalue>[0]);
            }

            maxP = capacity; 
            originalMaxP = capacity;
        }

        public LinearHashTable()
            : this(16, 5) { }

        private bool IsPowerOfTwo(ulong x)
        {
            return (x & (x - 1)) == 0;
        }

        private int Hash(int gK)
        {
            return gK & (maxP - 1); 
        }

        private int HashNext(int gK)
        {
            return gK & (2 * maxP - 1);
        }

        private static int StandardHash(Tkey key)
        {
            return unchecked(key.GetHashCode());// % 1048583;
        }

        private Tkey lastKey = default(Tkey);
        private int lastAddr = 0;

        private int GetHashAddress(Tkey weightTableAddress)
        {
            if (weightTableAddress.Equals(lastKey))
            {
                return lastAddr;
            }

            int gK = StandardHash(weightTableAddress);
            int addr = Hash(gK);

            if (addr < p)
            {
                addr = HashNext(gK);
            }
            lastAddr = addr;
            lastKey = weightTableAddress;
            return addr;
        }

        private void IncreaseBuckets()
        {
            int newLastAddress = keyValue.Count; 
            KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[p];
            int length = keyValueCache.Length - 1;

            newItems.Clear();
            delItems.Clear();

            for (int i = length; i >= 0; --i)
            {
                int hash = HashNext(StandardHash(keyValueCache[i].Key));

                if (hash == newLastAddress)
                {
                    newItems.Add(keyValueCache[i]);
                }
                else
                {
                    delItems.Add(keyValueCache[i]);
                }
            }

            keyValue.Add(newItems.ToArray());

            keyValue[p] = delItems.ToArray();

            if (++p == maxP)
            {
                maxP *= 2;
                p = 0;
            }
        }

        private void DecreaseBuckets()
        {
            p--;
            if (p < 0)
            {
                maxP /= 2;
                p = maxP;
            }

            int lastAddress = keyValue.Count - 1;
            KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[lastAddress];
            newItems.Clear();

            for (int i = 0; i < keyValueCache.Length; i++)
            {
                newItems.Add(keyValueCache[i]);
            }

            keyValueCache = keyValue[p];

            for (int i = 0; i < keyValueCache.Length; i++)
            {
                newItems.Add(keyValueCache[i]);
            }

            keyValue[p] = newItems.ToArray();
            keyValue.RemoveAt(lastAddress);
        }

        private bool LoadOver()
        {
            return (elementsOfArrayUsed > keyValue.Count * loadToMaintain);
        }

        private bool LoadUnder()
        {
            return (elementsOfArrayUsed < keyValue.Count * 1);
        }

        public void Add(KeyValuePair<Tkey, Tvalue> keyValuePair)
        {
            Add(keyValuePair.Key, keyValuePair.Value);
        }

        public void Clear()
        {
            keyValue.Clear();
            p = 0;
            elementsOfArrayUsed = 0;
            maxP = originalMaxP;
            lastKey = default(Tkey);
            lastAddr = 0;

            for (int i = 0; i < capacity; i++)
            {
                keyValue.Add(new KeyValuePair<Tkey, Tvalue>[0]);
            }
        }

        public void Add(Tkey key, Tvalue value)
        {
            int addr = GetHashAddress(key);
            KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[addr];
            int length = keyValueCache.Length;

            // NOTE: Here manually resizing is faster than using a List and converting to an array

            // Resize the array
            Array.Resize<KeyValuePair<Tkey, Tvalue>>(ref keyValueCache, length + 1);

            // Set the temporary keyValueCache entry to the key/value pair
            keyValueCache[length] = new KeyValuePair<Tkey, Tvalue>(key, value);

            // Replace the old key/value pair with the new one
            keyValue[addr] = keyValueCache;

            elementsOfArrayUsed++;

            while (LoadOver())
            {
                IncreaseBuckets();
            }
        }

        public bool ContainsKey(Tkey key)
        {
            int addr = GetHashAddress(key);

            for (int i = 0; i < keyValue[addr].Length; i++)
            {
                if (keyValue[addr][i].Key.Equals(key))
                {
                    return true;
                }
            }
            return false;
        }

        public bool Contains(KeyValuePair<Tkey, Tvalue> keyValuePair)
        {
            return ContainsKey(keyValuePair.Key);
        }

        public void CopyTo(KeyValuePair<Tkey, Tvalue>[] array, int arrayIndex)
        {
            int index = arrayIndex;
            for (int i = 0; i < keyValue.Count; i++)
            {
                for (int j = 0; j < keyValue[i].Length; j++)
                {
                    array[index++] = keyValue[i][j];
                }
            }
        }

        public bool Remove(Tkey key)
        {
            int addr = GetHashAddress(key);
            KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[addr];
            int length = keyValueCache.Length;

            List<KeyValuePair<Tkey, Tvalue>> keptItems = new List<KeyValuePair<Tkey, Tvalue>>();

            bool entered = false;
            for (int i = 0; i < length; i++)
            {
                if (keyValueCache[i].Key.Equals(key))
                {
                    entered = true;
                    for (int j = 0; j < length - 1; j++)
                    {
                        if (j != i)
                        {
                            keptItems.Add(keyValueCache[j]);
                        }
                    }
                }
            }

            if (!entered)
            {
                return false;
            }

            keyValue[addr] = keptItems.ToArray();

            if (LoadUnder())
            {
                DecreaseBuckets();
            }

            return true;
        }

        public bool Remove(KeyValuePair<Tkey, Tvalue> keyValue)
        {
            return Remove(keyValue.Key);
        }

        public bool TryGetValue(Tkey key, out Tvalue value, out int iterationAmount)
        {
            iterationAmount = 0;
            int addr = GetHashAddress(key);

            KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[addr];
            int count = keyValueCache.Length - 1;

            // Check the chain for the key
            for (int i = count; i >= 0; --i)
            {
                iterationAmount++;
                if (keyValueCache[i].Key.Equals(key))
                {
                    value = keyValueCache[i].Value;
                    return true;
                }
            }

            value = default(Tvalue);
            return false;
        }

        public Tvalue this[Tkey key]
        {
            get
            {
                int addr = GetHashAddress(key);
                KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[addr];
                int length = keyValueCache.Length;

                for (int i = length - 1; i >= 0; --i)
                {
                    if (keyValueCache[i].Key.Equals(key))
                    {
                        return keyValueCache[i].Value;
                    }
                }
                throw new KeyNotFoundException("Key was not in dictionary");
            }

            set
            {
                int addr = GetHashAddress(key);

                KeyValuePair<Tkey, Tvalue>[] keyValueCache = keyValue[addr];
                int count = keyValueCache.Length - 1;

                for (int i = count; i >= 0; --i)
                {
                    if (keyValueCache[i].Key.Equals(key))
                    {
                        keyValueCache[i] = new KeyValuePair<Tkey, Tvalue>(key, value);
                        return;
                    }
                }
                throw new KeyNotFoundException("Key was not in dictionary");
            }
        }

        public ICollection<Tkey> Keys
        {
            get
            {
                List<Tkey> keys = new List<Tkey>();
                for (int i = 0; i < keyValue.Count; i++)
                {
                    for (int j = 0; j < keyValue[i].Length; j++)
                    {
                        keys.Add(keyValue[i][j].Key);
                    }
                }
                return keys;
            }
        }

        public ICollection<Tvalue> Values
        {
            get
            {
                List<Tvalue> values = new List<Tvalue>();
                for (int i = 0; i < keyValue.Count; i++)
                {
                    for (int j = 0; j < keyValue[i].Length; j++)
                    {
                        values.Add(keyValue[i][j].Value);
                    }
                }
                return values;
            }
        }


        public int Count
        {
            get
            {
                return elementsOfArrayUsed;
            }
        }

        public float MemoryUsed
        {
            get
            {
                int mem = 0;
                for (int i = 0; i < keyValue.Count; i++)
                {
                    mem += keyValue[i].Length;
                }
                return (mem * 8f) / 1024f;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        public IEnumerator<KeyValuePair<Tkey, Tvalue>> GetEnumerator()
        {
            throw new NotImplementedException();
        }


        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public bool TryGetValue(Tkey key, out Tvalue value)
        {
            throw new NotImplementedException();
        }
    }
}